/*
 * Trevor Brandt
 * 07/15/2024
 * CS 210
 * 12 and 24 Hour Clock for Chada Tech
 */

#include <iostream>
#include <iomanip>
#include "Clock.h"

using namespace std;

/*
This function will display the menu options to the user.
No parameters are required.
No return value.
*/
void displayMenu() {
    cout << "*************************" << endl;
    cout << "* 1: Add One Hour       *" << endl;
    cout << "* 2: Add One Minute     *" << endl;
    cout << "* 3: Add One Second     *" << endl;
    cout << "* 4: Exit Program       *" << endl;
    cout << "*************************" << endl;
}

/*
This is the main function where the program starts execution.
No parameters are required.
Return 0 - integer
*/
int main() {
    int hour, minute, second;
    cout << "Enter the current time in 24-hour format (HH MM SS): ";
    cin >> hour >> minute >> second;

    /*
    Creating a Clock object in 24-hour format.
    Parameter hour - Integer
    Parameter minute - Integer
    Parameter second - Integer
    Parameter true - Boolean
    */
    Clock clock1(hour, minute, second, true);  // 24-hour format

    /*
    Creating a Clock object in 12-hour format.
    Parameter hour - Integer
    Parameter minute - Integer
    Parameter second - Integer
    Parameter false - Boolean
    */
    Clock clock2(hour, minute, second, false); // 12-hour format
    int choice;

    while (true) {

        cout << "*****************************" << endl;
        cout << "* Clock 1 (24-hour format): *" << endl;
        clock1.displayTime();
        cout << "*****************************" << endl;

        cout << "*****************************" << endl;
        cout << "* Clock 2 (12-hour format): *" << endl;
        clock2.displayTime();
        cout << "*****************************" << endl;

        displayMenu();
        cin >> choice;

        switch (choice) {
        case 1:
            clock1.addHour();
            clock2.addHour();
            break;
        case 2:
            clock1.addMinute();
            clock2.addMinute();
            break;
        case 3:
            clock1.addSecond();
            clock2.addSecond();
            break;
        case 4:
            return 0;
        default:
            cout << "Invalid choice. Please try again.\n";
        }
    }
    return 0;
}
