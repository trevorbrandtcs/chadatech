#ifndef CLOCK_H
#define CLOCK_H

/*
This is the Clock class. It represents a clock that can display time in both 24-hour and 12-hour formats.
*/
class Clock {

private:
    int hours;   // This represents the hours in the clock.
    int minutes; // This represents the minutes in the clock.
    int seconds; // This represents the seconds in the clock.
    bool is24Hour; // This represents the format of the clock. If true, the clock is in 24-hour format. If false, it's in 12-hour format.

public:
    /*
    This is the constructor for the Clock class.
    Parameter h - Integer representing the hours.
    Parameter m - Integer representing the minutes.
    Parameter s - Integer representing the seconds.
    Parameter is24Hour - Boolean representing the format of the clock. Default value is true.
    */
    Clock(int h, int m, int s, bool is24Hour = true);

    /*
    This method will add one hour to the current time.
    No parameters are required.
    No return value.
    */
    void addHour();

    /*
    This method will add one minute to the current time.
    No parameters are required.
    No return value.
    */
    void addMinute();

    /*
    This method will add one second to the current time.
    No parameters are required.
    No return value.
    */
    void addSecond();

    /*
    This method will display the current time.
    No parameters are required.
    No return value.
    */
    void displayTime() const;

    /*
    This method will set the time to the provided hours, minutes, and seconds.
    Parameter h - Integer representing the hours.
    Parameter m - Integer representing the minutes.
    Parameter s - Integer representing the seconds.
    No return value.
    */
    void setTime(int h, int m, int s);
};

#endif